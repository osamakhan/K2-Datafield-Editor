﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SourceCode.Workflow.Client;
    
namespace K2DataFieldsEditor
{
    public partial class Home : Form
    {
        protected Connection K2Conn = new Connection();

        public Home()
        {
            InitializeComponent();
        }

        #region Form Events
        
        private void Home_Load(object sender, EventArgs e)
        {
            //Load default settings.
            txtK2Server.Text = K2DataFieldsEditor.Properties.Settings.Default.K2Server;
            txtK2Port.Text = K2DataFieldsEditor.Properties.Settings.Default.K2Port;
            txtK2Domain.Text = K2DataFieldsEditor.Properties.Settings.Default.K2Domain;
            txtK2Username.Text = K2DataFieldsEditor.Properties.Settings.Default.K2Username;
            txtK2Password.Text = K2DataFieldsEditor.Properties.Settings.Default.K2Password;

            //Setup default form state
            grpProcess.Enabled = false;
            grpDataFields.Enabled = false;
        }
        private void Home_FormClosed(object sender, FormClosedEventArgs e)
        {
            K2Conn.Close();
        }
        
        #endregion

        #region Control Events

        private void btnConnect_Click(object sender, EventArgs e)
        {
            string K2ServerName = txtK2Server.Text;
            string K2UserName = txtK2Username.Text;
            string K2ServerDomain = txtK2Domain.Text;
            string K2Password = txtK2Password.Text;
            uint K2Port = uint.Parse(txtK2Port.Text);

            SourceCode.Hosting.Client.BaseAPI.SCConnectionStringBuilder connectionString = new SourceCode.Hosting.Client.BaseAPI.SCConnectionStringBuilder();
            connectionString.Authenticate = true;
            connectionString.Host = K2ServerName;
            connectionString.Integrated = true;
            connectionString.IsPrimaryLogin = true;
            connectionString.Port = K2Port;
            connectionString.UserID = K2UserName;
            connectionString.WindowsDomain = K2ServerDomain;
            connectionString.Password = K2Password;
            connectionString.SecurityLabelName = "K2"; //the default label

            // open a K2 connection
            try
            {
                K2Conn.Open(K2ServerName, connectionString.ToString());
            }
            catch
            {
                MessageBox.Show("Could not open connection !");

                grpProcess.Enabled = false;
                grpDataFields.Enabled = false;
                
                return;
            }


            //Update settings with successful K2 values.
            Properties.Settings.Default.K2Server = txtK2Server.Text;
            Properties.Settings.Default.K2Port = txtK2Port.Text;
            Properties.Settings.Default.K2Domain = txtK2Domain.Text;
            Properties.Settings.Default.K2Username = txtK2Username.Text;
            Properties.Settings.Default.K2Password = txtK2Password.Text;

            //Enable form elements
            grpProcess.Enabled = true;
        }
        private void btnGetProcessData_Click(object sender, EventArgs e)
        {
            try
            {
                ProcessInstance objProcessInst;
                int processID = Convert.ToInt32(txtProcessID.Text);

                DataTable dtFields = new DataTable();
                dtFields.Columns.Add("DataField");
                dtFields.Columns.Add("Value");

                DataTable dtXMLFields = new DataTable();
                dtXMLFields.Columns.Add("XmlField");
                dtXMLFields.Columns.Add("Value");


                objProcessInst = K2Conn.OpenProcessInstance(processID);
                txtProcessName.Text = objProcessInst.FullName;

                foreach (DataField dField in objProcessInst.DataFields)
                {
                    DataRow dr = dtFields.NewRow();
                    dr["DataField"] = dField.Name;
                    dr["Value"] = dField.Value.ToString();
                    dtFields.Rows.Add(dr);
                }

                foreach (XmlField dField in objProcessInst.XmlFields)
                {
                    DataRow dr = dtXMLFields.NewRow();
                    dr["XmlField"] = dField.Name;
                    dr["Value"] = dField.Value.ToString();
                    dtXMLFields.Rows.Add(dr);
                }


                grdDataFields.DataSource = dtFields;
                grdXMLFields.DataSource = dtXMLFields;

                //Setup Columns
                grdDataFields.Columns[0].ReadOnly = true;
                grdDataFields.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                grdDataFields.Columns[0].HeaderText = "XMLField (Read Only)";

                grdDataFields.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                grdDataFields.Columns[1].HeaderText = "Value (Dbl. Click to Edit)";

                grdXMLFields.Columns[0].ReadOnly = true;
                grdXMLFields.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                grdXMLFields.Columns[0].HeaderText = "XMLField (Read Only)";

                grdXMLFields.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                grdXMLFields.Columns[1].HeaderText = "Value (Dbl. Click to Edit)";

            }
            catch
            {
                grpDataFields.Enabled = false;
                MessageBox.Show("Could not load Process Instance");
                return;
            }

            grpDataFields.Enabled = true;
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                ProcessInstance objProcessInst;
                int processID = Convert.ToInt32(txtProcessID.Text);
                objProcessInst = K2Conn.OpenProcessInstance(processID);

                //Update DataFields
                foreach (DataGridViewRow row in grdDataFields.Rows)
                {
                    string datafieldName = row.Cells[0].Value.ToString();
                    string datafieldValue = row.Cells[1].Value.ToString();

                    foreach (DataField dField in objProcessInst.DataFields)
                    {
                        //Check which DataField you want to update
                        if (dField.Name == datafieldName)
                        {
                            dField.Value = datafieldValue;
                        }
                    }
                }

                //Update XmlFields
                foreach (DataGridViewRow row in grdXMLFields.Rows)
                {
                    string datafieldName = row.Cells[0].Value.ToString();
                    string datafieldValue = row.Cells[1].Value.ToString();

                    foreach (XmlField dField in objProcessInst.XmlFields)
                    {
                        //Check which XmlField you want to update
                        if (dField.Name == datafieldName)
                        {
                            dField.Value = datafieldValue;
                        }
                    }
                }

                // Call Update Method to update the DatField value
                objProcessInst.Update();
            }
            catch
            {
                MessageBox.Show("Error updating data !");
                return;
            }

            grpDataFields.Enabled = false;
            grdDataFields.DataSource = null;
            grdDataFields.Rows.Clear();

            grpXMLFields.Enabled = false;
            grdXMLFields.DataSource = null;
            grdXMLFields.Rows.Clear();

            MessageBox.Show("Data updated successfully !");
        }

        #endregion

        #region Data Validation
        
        private void txtK2Port_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(e.KeyChar.ToString(), "\\d+"))
                e.Handled = true;
        }
        private void txtProcessID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(e.KeyChar.ToString(), "\\d+"))
                e.Handled = true;
        }

        #endregion
    }
}
