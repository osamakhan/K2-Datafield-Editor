﻿namespace K2DataFieldsEditor
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtK2Server = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtK2Port = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtK2Username = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtK2Password = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.grpConnection = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtK2Domain = new System.Windows.Forms.TextBox();
            this.grpProcess = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtProcessName = new System.Windows.Forms.TextBox();
            this.btnGetProcessData = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtProcessID = new System.Windows.Forms.TextBox();
            this.grpDataFields = new System.Windows.Forms.GroupBox();
            this.grdDataFields = new System.Windows.Forms.DataGridView();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.grpXMLFields = new System.Windows.Forms.GroupBox();
            this.grdXMLFields = new System.Windows.Forms.DataGridView();
            this.grpConnection.SuspendLayout();
            this.grpProcess.SuspendLayout();
            this.grpDataFields.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdDataFields)).BeginInit();
            this.grpXMLFields.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdXMLFields)).BeginInit();
            this.SuspendLayout();
            // 
            // txtK2Server
            // 
            this.txtK2Server.Location = new System.Drawing.Point(72, 9);
            this.txtK2Server.Name = "txtK2Server";
            this.txtK2Server.Size = new System.Drawing.Size(100, 20);
            this.txtK2Server.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "K2 Server :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Port :";
            // 
            // txtK2Port
            // 
            this.txtK2Port.Location = new System.Drawing.Point(72, 35);
            this.txtK2Port.Name = "txtK2Port";
            this.txtK2Port.Size = new System.Drawing.Size(100, 20);
            this.txtK2Port.TabIndex = 3;
            this.txtK2Port.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtK2Port_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(233, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Username :";
            // 
            // txtK2Username
            // 
            this.txtK2Username.Location = new System.Drawing.Point(300, 9);
            this.txtK2Username.Name = "txtK2Username";
            this.txtK2Username.Size = new System.Drawing.Size(100, 20);
            this.txtK2Username.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(235, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Password :";
            // 
            // txtK2Password
            // 
            this.txtK2Password.Location = new System.Drawing.Point(300, 35);
            this.txtK2Password.Name = "txtK2Password";
            this.txtK2Password.PasswordChar = '*';
            this.txtK2Password.Size = new System.Drawing.Size(100, 20);
            this.txtK2Password.TabIndex = 7;
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(334, 69);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 1;
            this.btnConnect.Text = "Connect !";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // grpConnection
            // 
            this.grpConnection.Controls.Add(this.label7);
            this.grpConnection.Controls.Add(this.txtK2Domain);
            this.grpConnection.Controls.Add(this.label1);
            this.grpConnection.Controls.Add(this.btnConnect);
            this.grpConnection.Controls.Add(this.txtK2Server);
            this.grpConnection.Controls.Add(this.txtK2Password);
            this.grpConnection.Controls.Add(this.label2);
            this.grpConnection.Controls.Add(this.label4);
            this.grpConnection.Controls.Add(this.txtK2Port);
            this.grpConnection.Controls.Add(this.txtK2Username);
            this.grpConnection.Controls.Add(this.label3);
            this.grpConnection.Location = new System.Drawing.Point(12, 12);
            this.grpConnection.Name = "grpConnection";
            this.grpConnection.Size = new System.Drawing.Size(415, 98);
            this.grpConnection.TabIndex = 9;
            this.grpConnection.TabStop = false;
            this.grpConnection.Text = "Connection";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Domain :";
            // 
            // txtK2Domain
            // 
            this.txtK2Domain.Location = new System.Drawing.Point(72, 61);
            this.txtK2Domain.Name = "txtK2Domain";
            this.txtK2Domain.Size = new System.Drawing.Size(100, 20);
            this.txtK2Domain.TabIndex = 10;
            // 
            // grpProcess
            // 
            this.grpProcess.Controls.Add(this.label6);
            this.grpProcess.Controls.Add(this.txtProcessName);
            this.grpProcess.Controls.Add(this.btnGetProcessData);
            this.grpProcess.Controls.Add(this.label5);
            this.grpProcess.Controls.Add(this.txtProcessID);
            this.grpProcess.Location = new System.Drawing.Point(12, 116);
            this.grpProcess.Name = "grpProcess";
            this.grpProcess.Size = new System.Drawing.Size(415, 82);
            this.grpProcess.TabIndex = 10;
            this.grpProcess.TabStop = false;
            this.grpProcess.Text = "Process Instance";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Process Type :";
            // 
            // txtProcessName
            // 
            this.txtProcessName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProcessName.Location = new System.Drawing.Point(90, 52);
            this.txtProcessName.Name = "txtProcessName";
            this.txtProcessName.ReadOnly = true;
            this.txtProcessName.Size = new System.Drawing.Size(188, 20);
            this.txtProcessName.TabIndex = 11;
            this.txtProcessName.Text = "N/A";
            // 
            // btnGetProcessData
            // 
            this.btnGetProcessData.Location = new System.Drawing.Point(284, 53);
            this.btnGetProcessData.Name = "btnGetProcessData";
            this.btnGetProcessData.Size = new System.Drawing.Size(125, 23);
            this.btnGetProcessData.TabIndex = 3;
            this.btnGetProcessData.Text = "Load Process Data";
            this.btnGetProcessData.UseVisualStyleBackColor = true;
            this.btnGetProcessData.Click += new System.EventHandler(this.btnGetProcessData_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "ProcessID :";
            // 
            // txtProcessID
            // 
            this.txtProcessID.Location = new System.Drawing.Point(72, 19);
            this.txtProcessID.Name = "txtProcessID";
            this.txtProcessID.Size = new System.Drawing.Size(100, 20);
            this.txtProcessID.TabIndex = 2;
            this.txtProcessID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProcessID_KeyPress);
            // 
            // grpDataFields
            // 
            this.grpDataFields.Controls.Add(this.grdDataFields);
            this.grpDataFields.Location = new System.Drawing.Point(12, 205);
            this.grpDataFields.Name = "grpDataFields";
            this.grpDataFields.Size = new System.Drawing.Size(415, 334);
            this.grpDataFields.TabIndex = 11;
            this.grpDataFields.TabStop = false;
            this.grpDataFields.Text = "Data Fields";
            // 
            // grdDataFields
            // 
            this.grdDataFields.AllowUserToAddRows = false;
            this.grdDataFields.AllowUserToDeleteRows = false;
            this.grdDataFields.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdDataFields.Location = new System.Drawing.Point(7, 20);
            this.grdDataFields.Name = "grdDataFields";
            this.grdDataFields.Size = new System.Drawing.Size(402, 279);
            this.grdDataFields.TabIndex = 10;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(389, 545);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 4;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // grpXMLFields
            // 
            this.grpXMLFields.Controls.Add(this.grdXMLFields);
            this.grpXMLFields.Location = new System.Drawing.Point(433, 205);
            this.grpXMLFields.Name = "grpXMLFields";
            this.grpXMLFields.Size = new System.Drawing.Size(415, 334);
            this.grpXMLFields.TabIndex = 12;
            this.grpXMLFields.TabStop = false;
            this.grpXMLFields.Text = "XML Fields";
            // 
            // grdXMLFields
            // 
            this.grdXMLFields.AllowUserToAddRows = false;
            this.grdXMLFields.AllowUserToDeleteRows = false;
            this.grdXMLFields.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdXMLFields.Location = new System.Drawing.Point(7, 20);
            this.grdXMLFields.Name = "grdXMLFields";
            this.grdXMLFields.Size = new System.Drawing.Size(402, 279);
            this.grdXMLFields.TabIndex = 10;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 577);
            this.Controls.Add(this.grpXMLFields);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.grpDataFields);
            this.Controls.Add(this.grpProcess);
            this.Controls.Add(this.grpConnection);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Home";
            this.Text = "K2 DataField Editor";
            this.Load += new System.EventHandler(this.Home_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Home_FormClosed);
            this.grpConnection.ResumeLayout(false);
            this.grpConnection.PerformLayout();
            this.grpProcess.ResumeLayout(false);
            this.grpProcess.PerformLayout();
            this.grpDataFields.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdDataFields)).EndInit();
            this.grpXMLFields.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdXMLFields)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtK2Server;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtK2Port;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtK2Username;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtK2Password;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.GroupBox grpConnection;
        private System.Windows.Forms.GroupBox grpProcess;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtProcessID;
        private System.Windows.Forms.Button btnGetProcessData;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtProcessName;
        private System.Windows.Forms.GroupBox grpDataFields;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.DataGridView grdDataFields;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtK2Domain;
        private System.Windows.Forms.GroupBox grpXMLFields;
        private System.Windows.Forms.DataGridView grdXMLFields;
    }
}

